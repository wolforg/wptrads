<?php
/*
Plugin Name: WPTrads – Your Translations, at Home!
Plugin URI: https://wptrads.com
Description: Allow update translations from WPTrads.com
Version: 1.2
Author: Julio Potier
Author URI: https://21douze.fr
Tested up to: 5.4
Requires PHP: 5.6
Text Domain: wptrads
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
*/

// don't load directly
if ( ! defined( 'ABSPATH' ) ) {
	header( "Location: https://wptrads.com" );
	die();
}

// Plugin constants
define( 'WPTRADS_NAME',           'Wp Trads' );
define( 'WPTRADS_VERSION',        '1.2' );
define( 'WPTRADS_URL',            'https://wptrads.com/' );
define( 'WPTRADS__FILE__',        __FILE__ );
define( 'WPTRADS_ASSETS',         plugins_url( basename( dirname( WPTRADS__FILE__ ) ), 'wptrads' ) );
define( 'WPTRADS_EDD_URL',        WPTRADS_URL . '?edd_action=get_version&license=' );
define( 'WPTRADS_AJAX_URL',       WPTRADS_URL . 'wp-admin/admin-ajax.php?action=' );
define( 'WPTRADS_ASK_URL',        WPTRADS_URL . 'demander-une-traduction/' );
define( 'WPTRADS_PERMALINK',      WPTRADS_URL . 'download/' );
define( 'WPTRADS_LICENSES',      'wptrads_licenses' );
define( 'WPTRADS_SETTINGS',      'wptrads' );
define( 'WPTRADS_PRODUCTS',      'wptrads_products' );
define( 'WPTRADS_ASK',           'wptrads_ask' );
define( 'WPTRADS_COUNT_PLUGINS', 'wptrads_count_plugins' );
define( 'WPTRADS_COUNT_THEMES',  'wptrads_count_themes' );
define( 'WPTRADS_EDD_ITEM_ID',   60693 );

include( __DIR__ . '/inc/functions.php' );
include( __DIR__ . '/inc/back-end.php' );
include( __DIR__ . '/inc/WPTRADS_SL_Plugin_Updater.php' );

add_action( 'init', 'wptrads_load_textdomain' );
/**
 * Load plugin textdomain.
 */
function wptrads_load_textdomain() {
	load_plugin_textdomain( 'wptrads', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
}

register_activation_hook( __FILE__, 'wptrads_plugin_activation' );
/**
 * Create the cron and don't display the promo question for 1 week at start
 *
 * @since 1.0
 * @author Julio Potier
 *
 **/
function wptrads_plugin_activation() {
	wp_schedule_event( current_time( 'timestamp' ), 'twicedaily', 'wptrads_get_remote_data_cron' );
	set_transient( WPTRADS_ASK, 1, WEEK_IN_SECONDS );
}

register_uninstall_hook( __FILE__, 'wptrads_uninstall_hook' );
/**
 * Delete all created cron and options
 *
 * @since 1.0
 * @author Julio Potier
 *
 **/
function wptrads_uninstall_hook() {
	$licenses = wptrads_get_licenses();
	if ( ! empty( array_filter( $licenses ) ) ) {
		foreach ( wptrads_get_product_types() as $type => $data ) {
			if ( ! isset( $licenses[ $type ] ) || empty( $licenses[ $type ] ) ) {
				continue;
			}
			foreach ( $licenses[ $type ] as $_data ) {
				wp_clear_scheduled_hook( 'wptrads_refresh_key', [ $_data['key'] ] );
			}
		}
	}
	wp_clear_scheduled_hook( 'wptrads_get_remote_data_cron' );
	delete_option( WPTRADS_PRODUCTS );
	delete_option( WPTRADS_LICENSES );
	delete_option( WPTRADS_SETTINGS );
	delete_option( WPTRADS_COUNT_PLUGINS );
	delete_option( WPTRADS_COUNT_THEMES );
	delete_transient( WPTRADS_ASK );
}
