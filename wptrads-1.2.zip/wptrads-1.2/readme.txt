=== WPTrads – Your Translations, at Home! ===
Contributors: juliobox, wolforg
Tags: translation
Stable tag: 1.2
Requires at least: 5.2
Tested up to: 5.4
Requires PHP: 5.6
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Allow update translations from WPTrads.com

== Description ==

Allow update translations from WPTrads.com, you can download free translations from our site.

== Installation ==

Add the plugin like any other plugin.

== Frequently Asked Questions ==


== Screenshots ==


== Changelog ==


== Upgrade Notice ==

1.2 - First release.
