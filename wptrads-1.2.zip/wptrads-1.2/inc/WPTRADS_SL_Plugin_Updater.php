<?php
// inc/WPTRADS_SL_Plugin_Updater.php

defined( 'ABSPATH' ) || die( 'You are not allowed to do that.' );


if ( ! class_exists( 'EDD_SL_Plugin_Updater' ) ) {
	// load our custom updater.
	include __DIR__ . '/EDD_SL_Plugin_Updater.php';
}


$active_plugins = get_option( 'active_plugins' );
foreach ( $active_plugins as $active_plugin ) {
	if ( false !== strpos( $active_plugin, 'wptrads.php' ) ) {
		$plugin_dir_and_filename = $active_plugin;
		break;
	}
}
if ( isset( $plugin_dir_and_filename ) ) {

	// setup the updater.
	$wptrads_edd_updater = new EDD_SL_Plugin_Updater(
		WPTRADS_URL,
		$plugin_dir_and_filename,
		array(
			'version' => WPTRADS_VERSION,
			'license' => 'c6a92a4411528787e1e44a0bb17edcdd', // this plugin is a free version, this key is public, no worries ;)
			'item_id' => WPTRADS_EDD_ITEM_ID,
			'author'  => 'Wolforg',
			'url'     => home_url(),
			'wp_override' => true,
			'cache_key' => 'wptrads',
		)
	);

}
