<?php
// inc/functions.php
defined( 'ABSPATH' ) || die( 'You are not allowed to do that.' );

/**
 * Return the type of trasnlation
 *
 * @since 1.0
 * @author Julio Potier
 *
 **/
function wptrads_is_what( $item ) {
	if ( wptrads_is_plugin( $item ) ) {
		return 'plugins';
	}
	if ( wptrads_is_theme( $item ) ) {
		return 'themes';
	}
	if ( wptrads_is_all_access( $item ) ) {
		return 'all_access';
	}
	return '';
}

/**
 * Return true if the translation is a plugin
 *
 * @since 1.0
 * @author Julio Potier
 *
 **/
function wptrads_is_plugin( $item ) {
	return 'extension' === $item['category_raw'];
}

/**
 * Return true if the translation is a theme
 *
 * @since 1.0
 * @author Julio Potier
 *
 **/
function wptrads_is_theme( $item ) {
	return 'theme' === $item['category_raw'];
}

/**
 * Return true if the translation is all access
 *
 * @since 1.0
 * @author Julio Potier
 *
 **/
function wptrads_is_all_access( $item ) {
	return 'abonnement' === $item['category_raw'];
}

/**
 * Return a licence data
 *
 * @since 1.0
 * @author Julio Potier
 *
 **/
function wptrads_get_licenses( $filter = 'all' )  {
	$data = get_option( WPTRADS_LICENSES, [] );
	if ( isset( $data[ $filter ] ) ) {
		return $data[ $filter ];
	}
	return $data;
}

/**
 * Return a product data
 *
 * @since 1.0
 * @author Julio Potier
 *
 **/
function wptrads_get_products( $filter = 'all' ) {
	$data = get_option( WPTRADS_PRODUCTS, [] );
	if ( isset( $data[ $filter ] ) ) {
		return $data[ $filter ];
	}
	return $data;
}

/**
 * Return a wptrads.com permalink
 *
 * @since 1.0
 * @author Julio Potier
 *
 **/
function wptrads_permalink( $slug ) {
	return WPTRADS_PERMALINK . $slug;
}

/**
 * Return the correct plugin folder name
 *
 * @since 1.0
 * @author Julio Potier
 *
 **/
function wptrads_get_plugin_folder( $path ) {
	$paths = explode( '/', $path );
	$path  = reset( $paths );
	return $path;
}

/**
 * Search a key deep in an array
 *
 * @since 1.0
 * @author Julio Potier
 *
 **/
function array_key_exists_deep( $key, $array ) {

	if ( array_key_exists( $key, $array ) ) {
		return true;
	}

	foreach ( $array as $_array ) {
		if ( is_array( $_array ) && array_key_exists_deep( $key, $_array ) ) {
			return true;
		}
	}

	return false;
}

/**
 * Return product types
 *
 * @since 1.0
 * @author Julio Potier
 *
 **/
function wptrads_get_product_types() {
	return [ 'all_access', 'plugins', 'themes' ];
}

/**
 * Return our setting error type
 *
 * @since 1.0
 * @author Julio Potier
 *
 **/
function wptrads_add_settings_error( $setting, $code, $message, $type = 'error' ) {
	if ( defined( 'DOING_CRON' ) && DOING_CRON ) {
		return;
	}
	add_settings_error( $setting, $code, $message, $type );
}

add_filter( 'pre_update_option_stylesheet', 'wptrads_switch_theme', 10, 3 );
/**
 * Don't switch theme is the new string is empty
 *
 * @since 1.2
 * @author Julio Potier
 *
 **/
function wptrads_switch_theme( $value, $old_value, $option ) {
	if ( empty( $value ) ) {
		return $old_value;
	}
	return $value;
}
