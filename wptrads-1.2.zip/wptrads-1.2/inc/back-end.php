<?php
// inc/back-end.php

defined( 'ABSPATH' ) || die( 'You are not allowed to do that.' );

add_filter( 'plugin_action_links_' . plugin_basename( WPTRADS__FILE__ ), 'wptrads_settings_action_links' );
/**
 * Add a link for translations in plugin actions
 *
 * @since 1.0
 * @author Julio Potier
 *
 **/
function wptrads_settings_action_links( $links ) {
	array_unshift( $links, '<a href="' . admin_url( 'admin.php?page=wptrads' ) . '">' . __( 'Your licenses', 'wptrads' ) . '</a>' );
	return $links;
}

add_action( 'admin_menu', 'wptrads_back_office' );
/**
 * Add out menu + register our setting
 *
 * @since 1.0
 * @author Julio Potier
 *
 **/
function wptrads_back_office() {
	add_menu_page( WPTRADS_NAME . ' — ' . __( 'Your licenses', 'wptrads' ), WPTRADS_NAME, 'manage_options', 'wptrads', 'wptrads_setting_page', 'dashicons-translation' );
	register_setting( 'wptrads_settings', WPTRADS_SETTINGS, 'wptrads_settings_cb' );
}

/**
 * The setting page callback
 *
 * @since 1.0
 * @author Julio Potier
 *
 **/
function wptrads_setting_page() {
	add_settings_section( 'wptrads_settings', __( '', 'wptrads' ), '__return_false', 'wptrads_settings' );
	add_settings_field( 'wptrads_settings_key', __( 'Add New License Key', 'wptrads' ), 'wptrads_settings_key_field',  'wptrads_settings', 'wptrads_settings' );
	add_settings_field( 'wptrads_settings_keys', '', 'wptrads_settings_keys_field', 'wptrads_settings', 'wptrads_settings' );
	?>
	<div class="wrap">
		<h1><?php echo WPTRADS_NAME; ?> —  <?php _e( 'Your licenses', 'wptrads' ); ?></h1>
		<p class="description"><?php _e( 'A plugin made to make it easier for you to manage your translations on Wp Trads.<br>Made by <a href="https://21douze.fr" target="_blank">Julio Potier</a> and <a href="https://wptrads.com" target="_blank">Didier Demory</a>.', 'wptrads' ); ?></p>
		<form action="options.php" method="post">
			<?php settings_fields( 'wptrads_settings' ); ?>
			<?php do_settings_sections( 'wptrads_settings' ); ?>
		</form>
	</div>
	<?php
}

/**
 * Our setting callback
 *
 * @since 1.0
 * @author Julio Potier
 *
 **/
function wptrads_settings_cb( $settings, $refresh = false ) {
	static $done;
	if ( ! isset( $done ) ) {
		$done = true;
	} else {
		return $settings;
	}

	$licenses = wptrads_get_licenses();
	$products = wptrads_get_products();

	// The key is not sent.
	if ( ! isset( $settings['key'] ) ) {
		wptrads_add_settings_error( 'wptrads', 'license_not_found', sprintf( __( 'Error %d: %s', 'wptrads' ), __LINE__, __( 'License not found', 'wptrads' ) ), 'error is-dismissible' );
		return $settings;
	}

	// The key is not a valid key format.
	if ( ! preg_match( '/^[a-f0-9]{32}$/i', $settings['key'] ) ) {
		wptrads_add_settings_error( 'wptrads', 'invalid_key', __( 'This license’s format is not valid.' ), 'error is-dismissible' );
		return $settings;
	}

	// Prepare the header and send the HTTP request.
	$args     = [ 'headers' => [ 'X-Requested-With' => 'WPTRADS; ' . get_bloginfo( 'url' ) ] ];
	$response = wp_remote_get( WPTRADS_EDD_URL . $settings['key'], $args );

	// Bad response = say it's an error.
	if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
		// wptrads_add_settings_error( 'wptrads', 'error', sprintf( __( 'Error %d: %s', 'wptrads' ), __LINE__, wp_remote_retrieve_response_message( $response ) ), 'error is-dismissible' );
		wptrads_add_settings_error( 'wptrads', 'invalid_key', sprintf( __( 'This license returns an error: %s' ), wp_remote_retrieve_response_message( $response ) ), 'error is-dismissible' );
		return $settings;
	}

	// Get the data from remote site.
	$data = @json_decode( wp_remote_retrieve_body( $response ), true );

	// incorrect data ? say it's an error.
	if ( ! $data ) {
		wptrads_add_settings_error( 'wptrads', 'license_not_found', sprintf( __( 'Error %d: %s', 'wptrads' ), __LINE__, __( 'License not found', 'wptrads' ) ), 'error is-dismissible' );
		return $settings;
	// Else parse it
	} elseif ( isset( $data['msg'], $data['info'] ) ) {
		// This was a pack key, display the children keys.
		if ( 'pack' === $data['info'] ) {
			$children                   = '';
			foreach ( $data['more_info'] as $key => $title ) {
				$children              .= sprintf( '<p><em>%s</em>: <code>%s</code></p>', esc_html( $title ), esc_html( $key ) );
			}
			$info                       = sprintf( __( 'This is a key for a pack, please add each license key instead: %s', 'wptrads' ), $children );
		}
		$info = isset( $children ) ? $info : esc_html( $data['info'] );
		if ( '404' === $info ) {
			$info = __( 'License not found', 'wptrads' );
		}
		wptrads_add_settings_error( 'wptrads', 'error', sprintf( __( 'Error %d: %s', 'wptrads' ), __LINE__, $info ), 'error is-dismissible' );
		return $settings;
	}

	// Build the 2 DB options : one for the setting page, one for the products.
	$slug                               = $data['slug'];
	$prefix                             = wptrads_is_what( $data );
	// This product already registered.
	if ( ! $refresh && isset( $licenses[ $prefix ][ $slug ] ) ) {
		wptrads_add_settings_error( 'wptrads', 'already_exists', __( 'This product already exists.', 'wptrads' ), 'error is-dismissible' );
		return $settings;
	}
	$data['icon']                       = unserialize( $data['icons'] )['1x'];
	// We don't need this.
	unset( $data['slug'], $data['stable_version'], $data['homepage'], $data['url'], $data['download_link'], $data['sections'], $data['banners'] , $data['icons'] );
	$data['key']                        = $settings['key'];
	$products[ $prefix ][ $slug ]       = $data;
	if ( ! $refresh && isset( $products[ $prefix ]['last_update'] ) ) {
		$products[ $prefix ]['last_update'] = '0';
	}
	// We don't need this.
	unset( $data['package'], $products[ $prefix ][ $slug ]['last_updated'], $products[ $prefix ][ $slug ]['customer'], $products[ $prefix ][ $slug ]['product_ID'], $products[ $prefix ][ $slug ]['license_ID'], $products[ $prefix ][ $slug ]['upgrade_paths'], $products[ $prefix ][ $slug ]['expiration'], $products[ $prefix ][ $slug ]['category'], $products[ $prefix ][ $slug ]['activation_count'], $products[ $prefix ][ $slug ]['activation_limit'], $products[ $prefix ][ $slug ]['key'] );
	$licenses[ $prefix ][ $slug ]       = $data;
	// Say it's ok.
	wptrads_add_settings_error( 'wptrads', 'license_ok', __( 'License successfully added.', 'wptrads' ), 'notice-success is-dismissible' );
	// Update the things.
	update_option( WPTRADS_LICENSES, $licenses );
	update_option( WPTRADS_PRODUCTS, $products );
	// Get the remote data again.
	wptrads_get_remote_data();
	// Create an auto refresh for this key every 12 hours.
	if ( ! wp_next_scheduled( 'wptrads_refresh_key_cron-' . $data['key'] ) ) {
		wp_schedule_event( current_time( 'timestamp' ), 'twicedaily', 'wptrads_refresh_key', [ $data['key'] ] );
	}

	return $settings;
}

/**
 * A field for key input
 *
 * @since 1.0
 * @author Julio Potier
 *
 **/
function wptrads_settings_key_field() {
?>
	<p>
		<input type="text" pattern="[a-fA-F\d]{32}" maxlength="32" onchange="this.value=this.value.replace(/[^a-f0-9]/gi,'')" title="<?php _e( '32 hexadecimal chars length', 'wptrads' ); ?>" name="wptrads[key]" class="regular-text">
		<?php submit_button( __( 'Add', 'wptrads' ), 'primary small', 'submit', false ); ?>
	</p>
<?php
}

/**
 * Add fake field to display keys
 *
 * @since 1.0
 * @author Julio Potier
 *
 **/
function wptrads_settings_keys_field() {
	$licenses = array_filter( wptrads_get_licenses() );
	?>
	<table class="wp-list-table widefat fixed striped posts" sqtyle="position: absolute;left: 0px;width: 99%;">
		<thead>
			<tr>
				<td id="status" class="manage-column column-cb check-column" style="width:10px"></td>
				<th scope="col" id="icon" class="manage-column column-icon column-primary" style="width:40px"></th>
				<th scope="col" id="title" class="manage-column column-title column"><?php _e( 'Title', 'wptrads' ); ?></th>
				<th scope="col" id="key" class="manage-column column-key"><?php _e( 'Key', 'wptrads' ); ?></th>
				<th scope="col" id="sites" class="manage-column column-sites" style="width:45px"><?php _e( 'Sites', 'wptrads' ); ?></th>
				<th scope="col" id="status" class="manage-column column-status"><?php _e( 'Status', 'wptrads' ); ?></th>
				<th scope="col" id="customer" class="manage-column column-customer"><?php _e( 'Customer', 'wptrads' ); ?></th>
				<th scope="col" id="date" class="manage-column column-date"><?php _e( 'Last Update', 'wptrads' ); ?></th>
			</tr>
		</thead>

		<tbody id="the-list">
	<?php
	if ( count( $licenses ) > 0 ) {
		$n = 0;
		foreach ( wptrads_get_product_types() as $_type ) {
			if ( ! isset( $licenses[ $_type ] ) || empty( $licenses[ $_type ] ) ) {
				continue;
			}
			foreach ( $licenses[ $_type ] as $slug => $data ) {
				$link               = 1 === $data['upgrade_paths'] ? sprintf( ' | <a href="%s" target="_blank">%s</a>', esc_url( add_query_arg( [ 'action' => 'manage_licenses', 'view' => 'upgrades' , 'license_id' => $data['license_ID']], WPTRADS_URL . 'compte/' ) ), '%s' ) : '';
				$expiration         = 'lifetime' === $data['expiration'] ? __( 'Never expire.', 'wptrads' ) : sprintf( __( 'expires on %s', 'wptrads' ), date_i18n( get_option( 'date_format' ), $data['expiration'] ) );
				switch ( $data['status'] ) {
					case 'atlimit' :
						$status     = sprintf( '<span style="font-weight:bold;color:#%s"><span class="dashicons dashicons-%s"></span> %s</span><br><em>%s</em>', '00A', 'warning', __( 'At Limit', 'wptrads' ), $expiration );
						$link       = sprintf( $link, __( 'Get More Sites', 'wptrads' ) );
					break;
					case 'expired' :
						$expiration = 'lifetime' === $data['expiration'] ? __( 'Lifetime', 'wptrads' ) : sprintf( __( 'since %s', 'wptrads' ), date_i18n( get_option( 'date_format' ), $data['expiration'] ) );
						$link       = sprintf( ' | <a href="%s" target="_blank">%s</a>', esc_url( add_query_arg( [ 'edd_license_key' => $data['key'], 'download_id' => $data['product_ID'] ], WPTRADS_URL . 'commander/' ) ), __( 'Renew Your License', 'wptrads' ) );
						$status     = sprintf( '<span style="font-weight:bold;color:#%s"><span class="dashicons dashicons-%s"></span> %s</span><br><em>%s</em>', 'A00', 'dismiss', __( 'Expired', 'wptrads' ), $expiration );
					break;
					default :
						$status     = sprintf( '<span style="font-weight:bold;color:#%s"><span class="dashicons dashicons-%s"></span> %s</span><br><em>%s</em>', '0A0', 'yes-alt', __( 'Valid', 'wptrads' ), $expiration );
						$link       = sprintf( $link, __( 'Upgrade Your Plan', 'wptrads' ) );
					break;
				}
				?>
				<tr id="post-<?php echo $n; ?>" class="iedit author-self level-0 post-<?php echo $n; ?> type-license status-<?php echo sanitize_html_class( $data['status'] ); ?>">
					<td class="manage-column column-cb check-column" style="padding-left: 15px;"></td>
					<td class="icon column-title has-row-actions column-primary" data-colname="<?php _e( 'Icon', 'wptrads' ); ?>">
						<img src="<?php echo esc_url( $data['icon'] ); ?>" height="48" width="48" alt="<?php echo esc_attr( $data['name'] ); ?>" />
					</td>
					<td class="title column-title has-row-actions column-primary page-title" data-colname="<?php _e( 'Title', 'wptrads' ); ?>">
						<strong>
							<span class="dashicons dashicons-<?php echo esc_attr( $data['category'] ); ?>"></span>
							<a class="row-title" target="_blank" href="<?php echo esc_url( wptrads_permalink( $slug ) ); ?>" aria-label="“<?php echo esc_attr( $data['name'] ); ?>” (<?php _e( 'on WPTrads.com', 'wptrads' ); ?>)">
								<?php echo esc_html( $data['name'] ); ?>
							</a>
							<?php
							$path = $slug . '/' . key( get_plugins( '/' . $slug ) ); // https://core.trac.wordpress.org/ticket/15907 …
							$all_plugins = get_plugins();
							if ( ! wptrads_is_all_access( $data ) && wptrads_is_plugin( $data ) ) {
								if ( ! isset( $all_plugins[ $path ] ) ) {
									printf( '<br>⚠️&nbsp;<span class="post-state">%s</span>', __( 'Plugin not installed', 'wptrads' ) );
								} elseif ( ! is_plugin_active( $path ) ) {
									printf( '<br>⚠️&nbsp;<span class="post-state">%s</span>', __( 'Plugin deactivated', 'wptrads' ) );
								}
							}
							?>
						</strong>

						<div class="row-actions">
							<span class="edit"><a href="<?php echo wp_nonce_url( admin_url( 'admin-post.php?action=wptrads_refresh_key&index=' . $slug ), 'wptrads_refresh_key-' . $slug ); ?>" aria-label="<?php _e( 'Refresh License Informations', 'wptrads' ); ?>"><?php _e( 'Refresh', 'wptrads' ); ?></a> | </span>
							<span class="trash"><a href="<?php echo wp_nonce_url( admin_url( 'admin-post.php?action=wptrads_remove_key&index=' . $slug ), 'wptrads_remove_key-' . $slug ); ?>" class="submitdelete" aria-label="<?php _e( 'Delete License Key', 'wptrads' ); ?>"><?php _e( 'Remove', 'wptrads' ); ?></a></span>
							<?php
							echo $link;
							?>
						</div>
					</td>
					<td class="key column-key" style="white-space: nowrap;" data-colname="<?php _e( 'Key', 'wptrads' ); ?>">
						<code><?php echo esc_html( $data['key'] ); ?></code>
					</td>
					<td class="sites column-key" data-colname="<?php _e( 'Sites', 'wptrads' ); ?>">
						<?php echo esc_html( $data['activation_count'] ); ?>&nbsp;/&nbsp;<?php echo 0 === $data['activation_limit'] ? '&infin;' : esc_html( $data['activation_limit'] ); ?>
					</td>
					<td class="status column-key" data-colname="<?php _e( 'Status', 'wptrads' ); ?>">
						<?php echo $status; ?>
					</td>
					<td class="customer column-key" data-colname="<?php _e( 'Customer', 'wptrads' ); ?>">
						<?php printf( '%s<br><em>%s</em>',
							esc_html( $data['customer']['name'] ),
							esc_html( $data['customer']['email'] )
						); ?>
					</td>
					<td class="date column-date" data-colname="<?php _e( 'Last Update', 'wptrads' ); ?>">
						<?php
						if ( wptrads_is_all_access( $data ) ) {
							echo '—';
						} else {
							$ago = sprintf( __( '<abbr title="%s">%s</abbr> ago', 'wptrads' ), esc_html( $data['last_updated'] ), esc_html( human_time_diff( strtotime( $data['last_updated'] ) ) ) );
							printf( 'v%s, %s', esc_html( $data['new_version'] ), $ago );
						}
						?>
					</td>
				</tr>
			<?php
			}
		}
	} else {
	?>
	<tr class="no-items"><td></td><td class="colspanchange" colspan="7"><?php _e( 'Not found', 'wptrads' ); ?></td></tr>
	<?php
	}
	?>
		</tbody>
		<tfoot>
			<tr>
				<td class="manage-column column-cb check-column"></td>
				<th scope="col" class="manage-column column-icon column-primary"></th>
				<th scope="col" class="manage-column column-title"><?php _e( 'Title', 'wptrads' ); ?></th>
				<th scope="col" class="manage-column column-key"><?php _e( 'Key', 'wptrads' ); ?></th>
				<th scope="col" class="manage-column column-sites"><?php _e( 'Sites', 'wptrads' ); ?></th>
				<th scope="col" class="manage-column column-status"><?php _e( 'Status', 'wptrads' ); ?></th>
				<th scope="col" class="manage-column column-customer"><?php _e( 'Customer', 'wptrads' ); ?></th>
				<th scope="col" class="manage-column column-date"><?php _e( 'Last Update', 'wptrads' ); ?></th>
			</tr>
		</tfoot>
	</table>
	<?php if ( ! defined( 'HIDE_WPTRADS_ADS' ) ) { ?>
	<hr>
	<div style="text-align:center">
		<h2><?php _e( 'Thanks to our partners', 'wptrads' ); ?></h2>
		<div id="o2switch">
			<h3><a href="https://o2switch.fr" target="_blank">o2switch</a></h3>
			<a href="https://o2switch.fr" target="_blank"><img src="<?php echo WPTRADS_ASSETS; ?>/assets/o2switch-ban.png" width="728" height="auto" alt="o2switch"/></a>
		</div>
		<hr width="700">
		<div id="beapi">
			<h3><a href="https://beapi.fr/notre-agence/be-api-communaute-wordpress/" target="_blank">BeApi</a></h3>
			<a href="https://beapi.fr/notre-agence/be-api-communaute-wordpress/" target="_blank"><img src="<?php echo WPTRADS_ASSETS; ?>/assets/beapi-ban.png" width="728" height="auto" alt="BeApi"/></a>
		</div>
		<hr width="700">
		<div id="kinsta">
			<h3><a href="https://kinsta.com/fr/" target="_blank">Kinsta</a></h3>
			<a href="https://kinsta.com/fr/" target="_blank"><img src="<?php echo WPTRADS_ASSETS; ?>/assets/kinsta-ban.png" width="728" height="auto" alt="Kinsta"/></a>
		</div>
		<hr width="700">
		<div id="wpmarmite">
			<h3>WP Marmite</h3>
			<?php printf( __( '%s from %s', 'wptrads' ), 'Alexandre Bortolotti', '<a href="https://wpmarmite.com/" target="_blank">WP Marmite</a>' ); ?>
		</div>
		<hr width="700">
	</div>
	<?php } ?>
<?php
}

add_filter( 'site_transient_update_plugins', 'wptrads_site_transient_update_plugins', 1000 );
/**
 * Hack the plugins transient to insert our content
 *
 * @since 1.0
 * @author Julio Potier
 *
 **/
function wptrads_site_transient_update_plugins( $current ) {
	global $pagenow, $current_screen;
	// We don't want to filter that on this page.
	if ( isset( $pagenow, $current_screen ) && 'update-core.php' === $pagenow ) {
		return $current;
	}
	$products   = wptrads_get_products( 'plugins' );
	if ( empty( $products ) ) {
		return $current;
	}
	if ( ! function_exists( 'get_plugins' ) ) {
		require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
	}
	$plugins    = get_plugins();
	foreach ( $plugins as $slug => $value ) {
		$folder = wptrads_get_plugin_folder( $slug );

		// If there is not already a plugin update but we need to display our available t9n (maybe just available online or maybe zip file).
		if ( ! isset( $current->response[ $slug ] ) && isset( $products[ $folder ] ) && version_compare( isset( $products[ $folder ]['last_update'] ) ? $products[ $folder ]['last_update'] : 0, $products[ $folder ]['new_version'], '<' ) ) {
			$current->response[ $slug ] = (object) [
													'id'          => microtime(),
													'slug'        => $folder,
													'plugin'      => $slug,
													'new_version' => $products[ $folder ]['new_version'],
													'url'         => wptrads_permalink( $folder ),
													'package'     => 'wptrads',
													'wptrads'     => true,
													];
		}

		// If we have the package file.
		if ( isset( $products[ $folder ]['package'] ) && version_compare( isset( $products[ $folder ]['last_update'] ) ? $products[ $folder ]['last_update'] : 0, $products[ $folder ]['new_version'], '<' ) ) {
			$current->translations[] = [
										'type'       => 'plugin',
										'slug'       => $folder,
										'language'   => 'fr_FR',
										'version'    => $products[ $folder ]['new_version'],
										'updated'    => isset( $products[ $folder ]['last_update'] ) ? $products[ $folder ]['last_update'] : 0,
										'package'    => $products[ $folder ]['package'],
										'autoupdate' => false,
										];
		}
	}
	return $current;
}

add_filter( 'site_transient_update_themes', 'wptrads_site_transient_update_themes', 1000 );
/**
 * Hack the themes transient to insert our content
 *
 * @since 1.0
 * @author Julio Potier
 *
 **/
function wptrads_site_transient_update_themes( $current ) {
	global $pagenow, $current_screen;
	// We don't want to filter that on this page.
	if ( isset( $pagenow, $current_screen ) && 'update-core.php' === $pagenow ) {
		return $current;
	}
	$products    = wptrads_get_products( 'themes' );
	if ( empty( $products ) ) {
		return $current;
	}
	if ( ! function_exists( 'wp_get_themes' ) ) {
		require_once( ABSPATH . 'wp-includes/theme.php' );
	}
	$themes      = wp_get_themes();
	foreach ( $themes as $folder => $value ) {
		if ( isset( $products[ $folder ] ) ) {
			if ( isset( $current->response[ $folder ] ) ) {
			}
		}
		// If there is not already a theme update but we need to display our available translation (maybe just available online or maybe zip file).
		if ( ! isset( $current->response[ $folder ] ) && isset( $products[ $folder ] ) && version_compare( isset( $products[ $folder ]['last_update'] ) ? $products[ $folder ]['last_update'] : 0, $products[ $folder ]['new_version'], '<' ) ) {
			$current->response[ $folder ] = [
											'theme'       => $folder,
											'new_version' => $products[ $folder ]['new_version'],
											'url'         => wptrads_permalink( $folder ),
											'package'     => 'wptrads',
											'wptrads'     => true,
											];
		}

		// If we have the package file.
		if ( isset( $products[ $folder ]['package'] ) && version_compare( isset( $products[ $folder ]['last_update'] ) ? $products[ $folder ]['last_update'] : 0, $products[ $folder ]['new_version'], '<' ) ) {
			$current->translations[] = [
										'type'       => 'theme',
										'slug'       => $folder,
										'language'   => 'fr_FR',
										'version'    => $products[ $folder ]['new_version'],
										'updated'    => isset( $products[ $folder ]['last_updated'] ) ? $products[ $folder ]['last_updated'] : 0,
										'package'    => $products[ $folder ]['package'],
										'autoupdate' => false,
										];
		}
	}
	return $current;
}

/**
 * Add the action to display our content below the plugin TR
 *
 * @since 1.0
 * @author Julio Potier
 *
 **/
function wptrads_plugin_update_rows() {
	if ( ! current_user_can( 'update_plugins' ) ) {
		return;
	}

	$plugins = get_site_transient( 'update_plugins' );
	if ( ! isset( $plugins->response ) || ! is_array( $plugins->response ) ) {
		return;
	}
	$plugins = array_keys( $plugins->response );
	foreach ( $plugins as $plugin_file ) {
		add_action( "after_plugin_row_$plugin_file", 'wptrads_plugin_update_row', 10, 2 );
	}
}

add_action( 'after_plugin_row', 'wptrads_after_plugin_row', 10, 2 );
/**
 * Display our content below the plugins when there is a translation available online
 *
 * @since 1.0
 * @author Julio Potier
 *
 **/
function wptrads_after_plugin_row( $plugin, $plugin_data ) {
	$folder        = wptrads_get_plugin_folder( $plugin );
	$products      = wptrads_get_products( 'plugins' );
	if ( ! isset( $products[ $folder ] ) || isset( $products[ $folder ]['package'] ) ) {
		return;
	}
	$wp_list_table = _get_list_table( 'WP_Plugins_List_Table' );
	printf(
		'<tr class="plugin-update-tr"><td colspan="%s" class="plugin-update colspanchange">' .
		'<div class="notice wptrads inline notice-info notice-alt"><p>%s</p></div>' .
		'</td></tr>',
		$wp_list_table->get_column_count(),
		sprintf( __( 'There is a new translation for %1$s %2$s available. <em><a href="%3$s" target="_blank">Get this translation</a>.</em>', 'wptrads' ),
			esc_html( $plugin_data['Name'] ),
			esc_html( $products[ $folder ]['new_version'] ),
			wptrads_permalink( $folder )
		)
	);
}

/**
 * Display out content ehe below the plugin when there is a translation available here.
 *
 * @since 1.0
 * @author Julio Potier
 *
 **/
function wptrads_plugin_update_row( $file, $plugin_data ) {
	$current = get_site_transient( 'update_plugins' );
	if ( ! isset( $current->response[ $file ] ) ) {
		return false;
	}

	$products    = wptrads_get_products( 'plugins' );
	$response    = $current->response[ $file ];
	$folder      = wptrads_get_plugin_folder( $file );

	$plugins_allowedtags = array(
		'a'       => array(
			'href'  => array(),
			'title' => array(),
		),
		'abbr'    => array( 'title' => array() ),
		'acronym' => array( 'title' => array() ),
		'code'    => array(),
		'em'      => array(),
		'strong'  => array(),
	);

	$plugin_name = wp_kses( $plugin_data['Name'], $plugins_allowedtags );
	$details_url = self_admin_url( 'plugin-install.php?tab=plugin-information&plugin=' . $response->slug . '&section=changelog&TB_iframe=true&width=600&height=800' );

	/** @var WP_Plugins_List_Table $wp_list_table */
	$wp_list_table = _get_list_table( 'WP_Plugins_List_Table' );

	if ( is_network_admin() || ! is_multisite() ) {
		if ( is_network_admin() ) {
			$active_class = is_plugin_active_for_network( $file ) ? ' active' : '';
		} else {
			$active_class = is_plugin_active( $file ) ? ' active' : '';
		}

		$requires_php   = isset( $response->requires_php ) ? $response->requires_php : null;
		$compatible_php = function_exists( 'is_php_version_compatible' ) ? is_php_version_compatible( $requires_php ) : true;
		$notice_type    = $compatible_php ? 'notice-warning' : 'notice-error';

		echo '<tr class="plugin-update-tr' . $active_class . '" id="' . esc_attr( $response->slug . '-update' ) . '" data-slug="' . esc_attr( $response->slug ) . '" data-plugin="' . esc_attr( $file ) . '"><td colspan="' . esc_attr( $wp_list_table->get_column_count() ) . '" class="plugin-update colspanchange">';

		if ( ! current_user_can( 'update_plugins' ) ) {
			if ( ! isset( $response->wptrads ) ) {
				echo '<div class="update-message notice inline ' . $notice_type . ' notice-alt"><p>';
				/* translators: 1: plugin name, 2: details URL, 3: additional link attributes, 4: version number */
				printf(
					__( 'There is a new version of %1$s available. <a href="%2$s" %3$s>View version %4$s details</a>.' ),
					$plugin_name,
					esc_url( $details_url ),
					sprintf(
						'class="thickbox open-plugin-details-modal" aria-label="%s"',
						/* translators: 1: plugin name, 2: version number */
						esc_attr( sprintf( __( 'View %1$s version %2$s details' ), $plugin_name, $response->new_version ) )
					),
					esc_attr( $response->new_version )
				);
			}
			if ( isset( $products[ $folder ] ) && version_compare( $products[ $folder ]['new_version'], isset( $products[ $folder ]['last_update'] ) ? $products[ $folder ]['last_update'] : 0, '>=' ) ) {
				echo '</p></div><div class="notice wptrads inline notice-info notice-alt"><p>';

				/* translators: 1: plugin name, 2: details URL, 3: additional link attributes, 4: version number */
				printf(
					__( 'There is a new translation for %1$s %2$s available.', 'wptrads' ),
					esc_html( $db_settings[ $folder ]['name'] ),
					esc_html( $db_settings[ $folder ]['new_version'] )
					);
			}
		} elseif ( empty( $response->package ) ) {
			if ( ! isset( $response->wptrads ) ) {
				echo '<div class="update-message notice wptrads inline ' . $notice_type . ' notice-alt"><p>';
				/* translators: 1: plugin name, 2: details URL, 3: additional link attributes, 4: version number */
				printf(
					__( 'There is a new version of %1$s available. <a href="%2$s" %3$s>View version %4$s details</a>. <em>Automatic update is unavailable for this plugin.</em>' ),
					$plugin_name,
					esc_url( $details_url ),
					sprintf(
						'class="thickbox open-plugin-details-modal" aria-label="%s"',
						/* translators: 1: plugin name, 2: version number */
						esc_attr( sprintf( __( 'View %1$s version %2$s details' ), $plugin_name, $response->new_version ) )
					),
					esc_attr( $response->new_version )
				);
			}
		} else {
			if ( $compatible_php ) {
				if ( ! isset( $response->wptrads ) ) {
					echo '<div class="update-message notice inline ' . $notice_type . ' notice-alt"><p>';
					/* translators: 1: plugin name, 2: details URL, 3: additional link attributes, 4: version number, 5: update URL, 6: additional link attributes */
					printf(
						__( 'There is a new version of %1$s available. <a href="%2$s" %3$s>View version %4$s details</a> or <a href="%5$s" %6$s>update now</a>.' ),
						$plugin_name,
						esc_url( $details_url ),
						sprintf(
							'class="thickbox open-plugin-details-modal" aria-label="%s"',
							/* translators: 1: plugin name, 2: version number */
							esc_attr( sprintf( __( 'View %1$s version %2$s details' ), $plugin_name, $response->new_version ) )
						),
						esc_attr( $response->new_version ),
						wp_nonce_url( self_admin_url( 'update.php?action=upgrade-plugin&plugin=' ) . $file, 'upgrade-plugin_' . $file ),
						sprintf(
							'class="update-link" aria-label="%s"',
							/* translators: %s: plugin name */
							esc_attr( sprintf( __( 'Update %s now' ), $plugin_name ) )
						)
					);
				}
				if ( isset( $products[ $folder ]['package'] ) && version_compare( $products[ $folder ]['new_version'], isset( $products[ $folder ]['last_update'] ) ? $products[ $folder ]['last_update'] : 0, '>' ) ) {
					echo '</p></div><div class="update-message notice wptrads inline notice-info notice-alt"><p>';
					$plugin_data = get_plugin_data( WP_PLUGIN_DIR . '/' . $folder );
					/* translators: 1: plugin name, 2: details URL, 3: additional link attributes, 4: version number, 5: update URL, 6: additional link attributes */
					printf(
						isset( $response->wptrads ) ? __( 'There is a new translation for %1$s %2$s available. <a href="%3$s" %4$s>Update now</a>.', 'wptrads' ) : __( 'There is a new translation for %1$s  %2$s available. <a href="%3$s" %4$s>Update now</a>.', 'wptrads' ),
						esc_html( $plugin_data['Name'] ),
						esc_html( $products[ $folder ]['new_version'] ),
						wp_nonce_url( self_admin_url( 'update.php?action=upgrade-plugin&plugin=' ) . $file, 'upgrade-plugin_' . $file ),
						sprintf(
							'class="update-link" aria-label="%s"',
							/* translators: %s: plugin name */
							esc_html( sprintf( __( 'Update %s now' ), $plugin_data['Name'] ) )
						)
					);
				}
			} else {
				if ( ! isset( $response->wptrads ) ) {
					echo '<div class="update-message notice inline ' . $notice_type . ' notice-alt"><p>';
					/* translators: 1: plugin name, 2: details URL, 3: additional link attributes, 4: version number 5: Update PHP page URL */
					printf(
						__( 'There is a new version of %1$s available, but it doesn&#8217;t work with your version of PHP. <a href="%2$s" %3$s>View version %4$s details</a> or <a href="%5$s">learn more about updating PHP</a>.' ),
						$plugin_name,
						esc_url( $details_url ),
						sprintf(
							'class="thickbox open-plugin-details-modal" aria-label="%s"',
							/* translators: 1: plugin name, 2: version number */
							esc_attr( sprintf( __( 'View %1$s version %2$s details' ), $plugin_name, $response->new_version ) )
						),
						esc_attr( $response->new_version ),
						esc_url( wp_get_update_php_url() )
					);
					wp_update_php_annotation( '<br><em>', '</em>' );
				}
			}
		}

		do_action( "in_plugin_update_message-{$file}", $plugin_data, $response );

		echo '</p></div></td></tr>';
	}
}

add_filter( 'views_plugins', 'wptrads_add_updated_plugin_view' );
/**
 * Only display the translations available
 *
 * @since 1.0
 * @author Julio Potier
 *
 **/
function wptrads_add_updated_plugin_view( $views ) {
	$update_plugins = get_site_transient( 'update_plugins' );
	if ( ! isset( $update_plugins->response ) ) {
		return $views;
	}
	$products       = wptrads_get_products( 'plugins' );
	$update_trans   = 0;
	$plugins        = get_plugins();
	foreach ( $products as $folder => $product ) {
		if ( isset( $product['new_version'] ) && version_compare( $product['new_version'], isset( $product['last_update'] ) ? $product['last_update'] : 0, '>' ) ) {
			foreach ( $plugins as $path => $data ) {
				if ( wptrads_get_plugin_folder( $path ) === $folder ) {
					$update_trans++;
				}
			}
		}
	}
	$type = 'translation';
	if ( $update_trans ) {
		$text = _x( 'Translation Available', 'wptrads' ) . sprintf( ' <span class="count">(%s)</span>', number_format_i18n( $update_trans ) );
		$link = sprintf( '<a href="%s"%s>%s</a>',
					add_query_arg( 'plugin_status', $type, admin_url( 'plugins.php' ) ),
					isset( $_GET['plugin_status'] ) && $type === $_GET['plugin_status'] ? ' class="current"' : '',
					$text
				);
		$views[ $type ] = $link;
	}
	return $views;
}

add_filter( 'all_plugins', 'wptrads_filter_translation_in_plugin_list' );
/**
 * Help the display of wptrads_add_updated_plugin_view()
 *
 * @since 1.0
 * @author Julio Potier
 *
 **/
function wptrads_filter_translation_in_plugin_list( $plugins ) {
	global $pagenow, $current_screen;
	// We don't want to filter that on this page.
	if ( isset( $pagenow, $current_screen ) && 'update-core.php' === $pagenow ) {
		return $plugins;
	}

	if ( 'plugins.php' !== $pagenow || ! isset( $_GET['plugin_status'] ) || 'translation' !== $_GET['plugin_status'] ) {
		return $plugins;
	}
	$products       = wptrads_get_products( 'plugins' );
	$update_trans   = [];
	foreach ( $products as $folder => $product ) {
		if ( isset( $product['new_version'] ) && version_compare( $product['new_version'], isset( $product['last_update'] ) ? $product['last_update'] : 0, '>' ) ) {
			foreach ( $plugins as $path => $data ) {
				if ( wptrads_get_plugin_folder( $path ) === $folder ) {
					$update_trans[ $path ] = $plugins[ $path ];
				}
			}
		}
	}
	return $update_trans;
}

add_filter( 'load-plugins.php', 'wptrads_count_plugins' );
/**
 * Perform a remote update when a plugin has been added (only when you visit the plugins page)
 *
 * @since 1.0
 * @author Julio Potier
 *
 **/
function wptrads_count_plugins() {
	$count     = count( get_plugins() );
	$old_count = get_option( WPTRADS_COUNT_PLUGINS, 0 );
	if ( $count > $old_count ) {
		wptrads_get_remote_data();
	}
	update_option( WPTRADS_COUNT_PLUGINS, $count );
}

add_filter( 'load-themes.php', 'wptrads_count_themes' );
/**
 * Perform a remote update when a theme has been added (only when you visit the themes page)
 *
 * @since 1.0
 * @author Julio Potier
 *
 **/
function wptrads_count_themes() {
	$count     = count( wp_get_themes() );
	$old_count = get_option( WPTRADS_COUNT_THEMES, 0 );
	if ( $count > $old_count ) {
		wptrads_get_remote_data();
	}
	update_option( WPTRADS_COUNT_THEMES, $count );
}

add_action( 'admin_init', 'wptrads_admin_init' );
/**
 * Remove the WP action to add our + delete the fake setting + remove the query arg
 *
 * @since 1.0
 * @author Julio Potier
 *
 **/
function wptrads_admin_init() {
	global $pagenow;
	remove_action( 'load-plugins.php', 'wp_plugin_update_rows', 20 );
	add_action( 'load-plugins.php', 'wptrads_plugin_update_rows', 20 );

	if ( 'options-general.php' === $pagenow && isset( $_GET['page'] ) && 'wptrads' === $_GET['page'] ) {
		delete_option( WPTRADS_SETTINGS );
	}
	if ( isset( $_GET['wptrads_msg'] ) ) {
		$_SERVER['REQUEST_URI'] = remove_query_arg( array( 'wptrads_msg' ), $_SERVER['REQUEST_URI'] );
	}
}

add_action( 'admin_notices', 'wptrads_admin_notices_center' );
/**
 * Set the correct notice
 *
 * @since 1.0
 * @author Julio Potier
 *
 **/
function wptrads_admin_notices_center() {
	global $current_screen;
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$msg_id = isset( $_GET['wptrads_msg'] ) ? (int) $_GET['wptrads_msg'] : 0;
	$msgs   = [
			'1' => [ 'status' => 'error',   'text' => __( 'License has not been removed.', 'wptrads' ) ],
			'2' => [ 'status' => 'success', 'text' => __( 'License has been successfully removed.', 'wptrads' ) ],
			'3' => [ 'status' => 'error',   'text' => __( 'License has not been reloaded.', 'wptrads' ) ],
			'4' => [ 'status' => 'success', 'text' => __( 'License has been successfully reloaded.', 'wptrads' ) ],
			];
	if ( 'settings_page_wptrads' === $current_screen->id ) {
		if ( isset( $msgs[ $msg_id ] ) ) {
			printf( '<div class="notice notice-%s is-dismissible"><p>%s</p></div>', $msgs[ $msg_id ]['status'], $msgs[ $msg_id ]['text'] );
			return;
		}
	}
	if ( 'plugins' === $current_screen->id ) {
		if ( isset( $msgs[ $msg_id ] ) ) {
			printf( '<div class="notice notice-%s is-dismissible"><p>%s</p></div>', $msgs[ $msg_id ]['status'], $msgs[ $msg_id ]['text'] );
			return;
		}
	}
	$transient_ask_translation = get_transient( WPTRADS_ASK );
	if( ! $transient_ask_translation ) {
		set_transient( WPTRADS_ASK, 1, MONTH_IN_SECONDS );
		switch ( $current_screen->id ) {
			case 'plugins':
				$what = _x( 'plugin', 'Need a translation for a %s?', 'wptrads' );
			break;
			case 'themes':
				$what = _x( 'theme', 'Need a translation for a %s?', 'wptrads' );
			break;
			default;
				$what = _x( 'plugin or theme', 'Need a translation for a %s?', 'wptrads' );
			break;
		}
		echo '<div class="notice wptrads notice-info is-dismissible"><p> ';
		printf( __( '<b>Need a translation for a specific %s?</b> We can do that for you with a fast delivery. <a href="%s" class="button button-primary small" target="_blank">Order your translation</a>', 'wptrads' ),
				$what,
				WPTRADS_ASK_URL
				);
		echo '</p></div>';
	}
}

add_action( 'admin_post_wptrads_remove_key', 'wptrads_remove_key_action_cb' );
/**
 * Callback to remove a key
 *
 * @since 1.0
 * @author Julio Potier
 *
 **/
function wptrads_remove_key_action_cb() {
	if ( ! isset( $_GET['_wpnonce'], $_GET['index'] ) || ! wp_verify_nonce( $_GET['_wpnonce'], 'wptrads_remove_key-' . $_GET['index'] ) ) {
		wp_safe_redirect( wp_get_referer() );
		die();
	}

	$index          = $_GET['index'];
	$return_url     = admin_url( 'options-general.php?page=wptrads&wptrads_msg=1' );
	$products       = wptrads_get_products();
	$licenses       = wptrads_get_licenses();
	foreach( wptrads_get_product_types() as $type ) {
		if ( ! isset( $licenses[ $type ][ $index ] ) ) {
			continue;
		}
		$key        = $licenses[ $type ][ $index ]['key'];
		unset( $licenses[ $type ][ $index ] );
		unset( $products[ $type ][ $index ] );
		if ( isset( $products['plugins'] ) ) {
			$products['plugins'] = array_intersect_key( $products['plugins'], $licenses['plugins'] );
		}
		if ( isset( $products['themes'] ) ) {
			$products['themes'] = array_intersect_key( $products['themes'], $licenses['themes'] );
		}
		update_option( WPTRADS_LICENSES, $licenses );
		update_option( WPTRADS_PRODUCTS, $products );
		$return_url = add_query_arg( 'wptrads_msg', '2', $return_url );
		wp_clear_scheduled_hook( 'wptrads_refresh_key', [ $key ] );
		break;
	}

	wp_safe_redirect( $return_url );
	die();
}

add_action( 'admin_post_wptrads_refresh_key', 'wptrads_refresh_key_action_cb' );
/**
 * Callback to refresh a licence key
 *
 * @since 1.0
 * @author Julio Potier
 *
 **/
function wptrads_refresh_key_action_cb() {
	if ( ! isset( $_GET['_wpnonce'], $_GET['index'] ) || ! wp_verify_nonce( $_GET['_wpnonce'], 'wptrads_refresh_key-' . $_GET['index'] ) ) {
		wp_safe_redirect( wp_get_referer() );
		die();
	}

	$index       = $_GET['index'];
	$return_url  = admin_url( 'options-general.php?page=wptrads&wptrads_msg=3' );
	$licenses    = wptrads_get_licenses();
	foreach( wptrads_get_product_types() as $_type ) {
		if ( ! isset( $licenses[ $_type ][ $index ] ) ) {
			continue;
		}
		$key = $licenses[ $_type ][ $index ]['key'];
		unset( $licenses[ $_type ][ $index ] );
		update_option( WPTRADS_LICENSES, $licenses );
		wptrads_refresh_key( $key );
		$return_url = add_query_arg( 'wptrads_msg', '4', $return_url );
	}

	wp_safe_redirect( $return_url );
	die();
}

add_action( 'wptrads_refresh_key', 'wptrads_refresh_key' );
/**
 * Refresh a key
 *
 * @since 1.0
 * @author Julio Potier
 *
 **/
function wptrads_refresh_key( $key = '' ) {
	wptrads_settings_cb( [ 'key' => $key ], true );
	wptrads_get_remote_data();
}

add_action( 'wptrads_get_remote_data_cron', 'wptrads_get_remote_data' );
add_action( 'switch_theme', 'wptrads_get_remote_data' );
/**
 * For cron + switch theme, get remote data
 *
 * @since 1.0
 * @author Julio Potier
 *
 **/
function wptrads_get_remote_data() {
	$plugins        = array_map( function( $path ) {
		$folder     = explode( '/', $path );
		return $folder[0];
	}, array_keys( get_plugins() ) );
	$licenses       = wptrads_get_licenses();
	$all_access_key = false;
	if ( isset( $licenses['all_access'] ) ) {
		foreach ( $licenses['all_access'] as $slug => $data ) {
			if ( wptrads_is_all_access( $data ) && ( 'active' === $data['status'] || 'valid' === $data['status'] ) ) {
				// Customer should not purchase more than 1 all_access key at the same time.
				$all_access_key = $data['key'];
				break;
			}
		}
	}
	$themes         = array_values( wp_list_pluck( wp_get_themes(), 'stylesheet' ) );
	$args           = [ 'headers' => [ 'X-Requested-With' => 'WPTRADS; ' . get_bloginfo( 'url' ) ], 'body' => [ 'all_access_key' => $all_access_key, 'plugins' => $plugins, 'themes' => $themes ] ];
	$response       = wp_remote_post( WPTRADS_AJAX_URL . 'wptrads_get_remote_data', $args );
	if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
		return;
	}
	$body           = wp_remote_retrieve_body( $response );
	$data           = json_decode( $body, true );
	$products       = wptrads_get_products();
	if ( isset( $data['success'] ) && $data['success'] ) {
		if ( isset( $data['data']['plugins'] ) && ! empty( $data['data']['plugins'] ) ) {
			foreach ( $data['data']['plugins'] as $folder => $_data ) {
				$products['plugins'][ $folder ]['new_version'] = $_data['new_version'];
				if ( isset( $_data['package'] ) ) {
					$products['plugins'][ $folder ]['package'] = $_data['package'];
				}
			}
		}
		if ( isset( $data['data']['themes'] ) && ! empty( $data['data']['themes'] ) ) {
			foreach ( $data['data']['themes'] as $folder => $_data ) {
				$products['themes'][ $folder ]['new_version'] = $_data['new_version'];
				if ( isset( $_data['package'] ) ) {
					$products['themes'][ $folder ]['package'] = $_data['package'];
				}
			}
		}
		update_option( WPTRADS_PRODUCTS, $products );
	}
}

add_filter( 'async_update_translation', 'wptrads_async_update_translation', 10, 2 );
/**
 * Set a global to only perform our translation
 *
 * @since 1.0
 * @author Julio Potier
 *
 **/
function wptrads_async_update_translation( $update, $language_update ) {
	global $wptrads_one_by_one;
	if ( isset( $wptrads_one_by_one ) ) {
		$update = wptrads_get_plugin_folder( $wptrads_one_by_one ) === $language_update->slug;
	}
	return $update;
}

add_action( 'upgrader_process_complete', 'wptrads_upgrader_process_complete_after_translation', 21, 2 );
/**
 * When the update is done, tag it done using the version unumber
 *
 * @since 1.0
 * @author Julio Potier
 *
 **/
function wptrads_upgrader_process_complete_after_translation( $_this, $args ) {
	global $wptrads_one_by_one;
	if ( ! isset( $args['bulk'] ) && 'update' === $args['action'] && 'translation' === $args['type'] ) {
		$products    = wptrads_get_products();
		if ( ! isset( $args['folder'] ) ) {
			return;
		}
		foreach ( wptrads_get_product_types() as $_type ) {
			if ( ! isset( $products[ $_type ][ $args['folder'] ]['package'] ) ) {
				continue;
			}
			$products[ $_type ][ $args['folder'] ]['last_update'] = $args['version'];
			update_option( WPTRADS_PRODUCTS, $products );
		}
	}
}

add_filter( 'upgrader_package_options', 'wptrads_upgrader_package_options_for_plugins' );
/**
 * Pre-download the plugin package to prevent display
 *
 * @since 1.0
 * @author Julio Potier
 *
 **/
function wptrads_upgrader_package_options_for_plugins( $options ) {
	if ( ! isset( $options['hook_extra']['plugin'] ) || 'wptrads' !== $options['package'] ) {
		return $options;
	}
	$folder                                 = wptrads_get_plugin_folder( $options['hook_extra']['plugin'] );
	$products                               = wptrads_get_products( 'plugins' );
	if ( isset( $products[ $folder ]['package'] ) ) {
		remove_all_filters( 'upgrader_source_selection' );
	} elseif ( ! isset( $products[ $folder ] ) ) {
		return $options;
	}
	$options['abort_if_destination_exists'] = false;
	$options['hook_extra']['wptrads']       = true;
	$options['hook_extra']['type']          = 'translation';
	$options['clear_destination']           = false;
	$options['clear_working']               = false;
	$options['destination']                 = WP_LANG_DIR . '/plugins/';
	$options['is_multi']                    = true;
	$download_package                       = $products[ $folder ]['package'];
	$download_file                          = download_url( $download_package, 300, false );
	$options['package']                     = $download_file;
	return $options;
}

add_filter( 'upgrader_package_options', 'wptrads_upgrader_package_options_for_themes' );
/**
 * Pre-download the theme package to prevent display
 *
 * @since 1.0
 * @author Julio Potier
 *
 **/
function wptrads_upgrader_package_options_for_themes( $options ) {
	if ( ! isset( $options['hook_extra']['theme'] ) || 'wptrads' !== $options['package'] ) {
		return $options;
	}
	$folder                                 = $options['hook_extra']['theme'];
	$products                               = wptrads_get_products( 'themes' );
	if ( isset( $products[ $folder ]['package'] ) ) {
		remove_all_filters( 'upgrader_source_selection' );
	} elseif ( ! isset( $products[ $folder ] ) ) {
		return $options;
	}
	$options['abort_if_destination_exists'] = false;
	$options['hook_extra']['wptrads']       = true;
	$options['hook_extra']['type']          = 'translation';
	$options['clear_destination']           = false;
	$options['clear_working']               = false;
	$options['destination']                 = WP_LANG_DIR . '/themes/';
	$options['is_multi']                    = true;
	$download_package                       = $products[ $folder ]['package'];
	$download_file                          = download_url( $download_package, 300, false );
	$options['package']                     = $download_file;
	return $options;
}

add_action( 'upgrader_pre_download', 'wptrads_upgrader_pre_download', 10, 3 );
/**
 * Hack the display to show the translation done, for all
 *
 * @since 1.0
 * @author Julio Potier
 *
 **/
function wptrads_upgrader_pre_download( $result, $package, $_this ) {
	global $wptrads_one_by_one;
	switch ( get_class( $_this->skin->upgrader ) ) {
		case 'Plugin_Upgrader':
		case 'Plugin_Upgrader_Skin':
			$update_plugins = get_site_transient( 'update_plugins' );
			if ( isset( $update_plugins->response[ $_this->skin->plugin ]->wptrads ) ) {
				$wptrads_one_by_one = $_this->skin->plugin;
				printf( '<div class="wrap"><h1>%s</h1>', __( 'Update Plugin Translation', 'wptrads' ) );
				$plugin = get_plugin_data( WP_PLUGIN_DIR . '/' . $_this->skin->plugin, false, false );
				$_this->skin->feedback( sprintf( __( 'Downloading translation for %s&hellip;', 'wptrads' ), $plugin['Name'] ) );
			}
		break;
		case 'Theme_Upgrader':
		case 'Theme_Upgrader_Skin':
			$update_themes = get_site_transient( 'update_themes' );
			if ( isset( $update_themes->response[ $_this->skin->theme ]['wptrads'] ) ) {
				$wptrads_one_by_one = $_this->skin->theme;
				printf( '<div class="wrap"><h1>%s</h1>', __( 'Update Theme Translation', 'wptrads' ) );
				$theme = wp_get_theme( $_this->skin->theme );
				$_this->skin->feedback( sprintf( __( 'Downloading translation for %s&hellip;', 'wptrads' ), $theme['Name'] ) );
				die();
			}
		break;
		case 'Language_Pack_Upgrader':
		case 'Language_Pack_Upgrader_Skin':
			$update_themes = get_site_transient( 'update_themes' );
			$products      = wptrads_get_products( 'themes' );
			if ( empty( $products ) ) {
				break;
			}
			if ( isset( $_this->skin->theme_info->template, $_this->skin->theme_info->template )
				&& isset( $update_themes->response[ $_this->skin->theme_info->template ]['wptrads'] )
				&& isset( $products[ $_this->skin->theme_info->template ]['package'] )
			) {
				remove_all_filters( 'upgrader_source_selection' );
			}
		break;
	}
	return $result;
}

add_filter( 'upgrader_post_install', 'wptrads_upgrader_post_install_for_plugins', 10, 3 );
/**
 * Hack the display to show the translation done, for plugins
 *
 * @since 1.0
 * @author Julio Potier
 *
 **/
function wptrads_upgrader_post_install_for_plugins( $return, $args_hook_extra, $this_result ) {
	if ( isset( $args_hook_extra['plugin'], $args_hook_extra['wptrads'] ) ) {
		if ( ! defined( 'DOING_AJAX' ) ) {
			$return      = new WP_Upgrader();
			$return->skin->feedback( __( 'Translation updated successfully.', 'wptrads' ) );
			printf( '</div><a href="%s" target="_parent">%s</a>', self_admin_url( 'plugins.php' ), __( 'Return to Plugins page' ) );
		}
		$folder      = wptrads_get_plugin_folder( $args_hook_extra['plugin'] );
		$products    = wptrads_get_products( 'plugins' );
		if ( isset( $products[ $folder ] ) ) {
			wptrads_upgrader_process_complete_after_translation( null, [ 'folder' => $folder, 'action' => 'update', 'type' => 'translation', 'version' => $products[ $folder ]['new_version'] ] );
		}
		if ( ! defined( 'DOING_AJAX' ) ) {
			include( ABSPATH . 'wp-admin/admin-footer.php' );
			die(); // Don't remove that one, this is not for debug ;).
		}
	}
	return $return;
}

add_filter( 'upgrader_post_install', 'wptrads_upgrader_post_install_for_themes', 10, 3 );
/**
 * Hack the display to show the translation done, for themes
 *
 * @since 1.0
 * @author Julio Potier
 *
 **/
function wptrads_upgrader_post_install_for_themes( $return, $args_hook_extra, $this_result ) {
	if ( isset( $args_hook_extra['theme'], $args_hook_extra['wptrads'] ) ) {
		if ( ! defined( 'DOING_AJAX' ) ) {
			$return      = new WP_Upgrader();
			$return->skin->feedback( __( 'Translation updated successfully.', 'wptrads' ) );
			printf( '</div><a href="%s" target="_parent">%s</a>', self_admin_url( 'themes.php' ), __( 'Return to Themes page' ) );
		}
		$folder      = $args_hook_extra['theme'];
		$products    = wptrads_get_products( 'themes' );
		if ( isset( $products[ $folder ] ) ) {
			wptrads_upgrader_process_complete_after_translation( null, [ 'folder' => $folder, 'action' => 'update', 'type' => 'translation', 'version' => $products[ $folder ]['new_version'] ] );
		}
		if ( ! defined( 'DOING_AJAX' ) ) {
			include( ABSPATH . 'wp-admin/admin-footer.php' );
			die(); // Don't remove that one, this is not for debug ;).
		}
	}
	return $return;
}

add_action( 'admin_print_styles-themes.php', 'wptrads_css' );
add_action( 'admin_print_styles-plugins.php', 'wptrads_css' );
/**
 * Some simple CSS rules, don't need a file for that
 *
 * @since 1.0
 * @author Julio Potier
 *
 **/
function wptrads_css() {
?>
<style>
.theme .notice.notice-fakeupdate-wptrads {
	top: 39px;
}
.notice.wptrads p:before {
	content:"\f326";
	color: #00a0d2;
	display: inline-block;
	font: normal 20px/1 'dashicons';
	-webkit-font-smoothing: antialiased;
	-moz-osx-font-smoothing: grayscale;
	vertical-align: top;
}
</style>
<?php
}

add_action( 'admin_print_footer_scripts', 'wptrads_add_translation_update_notices' );
/**
 * Add some JS, don't need a complicated located file for that
 *
 * @since 1.0
 * @author Julio Potier
 *
 **/
function wptrads_add_translation_update_notices() {
	global $pagenow;
	if ( 'themes.php' !== $pagenow || is_multisite() ) {
		return;
	}
	$products      = wptrads_get_products( 'themes' );
	if ( empty( $products ) ) {
		return;
	}
	$update_themes = get_site_transient( 'update_themes' );
	if ( empty( $update_themes->response ) ) {
		return;
	}
	?>
	<script>
	jQuery(function($) {
	<?php
	foreach ( $products as $theme_slug => $_product ) {
		if ( ! version_compare( $_product['new_version'], isset( $_product['last_update'] ) ? $_product['last_update'] : 0, '>' ) ) {
			continue;
		}
		$theme_name     = wp_get_theme( $theme_slug );
		$fake_update    = isset( $update_themes->response[ $theme_slug ]['wptrads'] );
		$css_class      = '';
		$button_dom     = '';
		if ( isset( $_product['package'] ) ) {
			$button_dom = sprintf( '<button class="button-link" type="button">%s</button>', esc_js( __( 'Update now', 'wptrads' ) ) );
			$css_class .= 'update-message ';
		} else {
			$button_dom = sprintf( '<a class="button-link" href="%s" target="_blank">%s</a>', wptrads_permalink( $theme_slug ), esc_js( __( 'Get this translation', 'wptrads' ) ) );
		}
		echo "<!--// $theme_name //-->\n";
		if ( ! $fake_update ) {
			$css_class  .= 'notice-fakeupdate-wptrads ';
		} else {
		?>
			$("div.theme[aria-describedby$=' <?php echo esc_js( $theme_slug ); ?>-name'] .update-message:not('.wptrads')").hide();
		<?php
		}
		?>
		$("div.theme[aria-describedby$=' <?php echo esc_js( $theme_slug ); ?>-name'] .theme-screenshot")
			.after( '<div class="<?php echo $css_class; ?>wptrads notice inline notice-info notice-alt"><p><?php echo esc_js( __( 'New translation available.', 'wptrads' ) ); ?> <?php echo $button_dom; ?></p></div>');
		<?php
		if ( ! current_user_can( 'update_themes' ) ) {
			// translators: 1: theme name, 2: version number
			$html = sprintf(
				'<p><strong>' . __( 'There is a new translation for %1$s %2$s available.', 'wptrads' ) . '</strong></p>',
				$theme_name,
				$_product['new_version']
			);
		} else {
			$update_url = add_query_arg(
				array(
					'action' => 'upgrade-theme',
					'theme'  => $theme_slug,
				),
				self_admin_url( 'update.php' )
			);
			// translators: 1: theme name, 2: version number, 3: update URL, 4: additional link attributes
			$html = sprintf(
				'<p><strong>' . __( 'There is a new translation for %1$s %2$s available. <a href="%3$s" %4$s>Update now</a>.', 'wptrads' ) . '</strong></p>',
				$theme_name,
				$_product['new_version'],
				esc_url( wp_nonce_url( $update_url, 'upgrade-theme_' . $theme_slug ) ),
				sprintf(
					'aria-label="%s" id="update-theme" class="update-link" data-slug="%s"',
					// translators: %s: theme name
					esc_attr( sprintf( __( 'Update %s now' ), $theme_name ) ),
					$theme_slug
				)
			);
		}
		if ( ! isset( $_GET['theme'] ) || $theme_slug !== $_GET['theme'] ) {
		?>
		$(".theme-browser .theme").on("click", function(e) {
		<?php
		}
		if ( ! $fake_update  ) {
		?>
			if ( '<?php echo esc_js( $theme_name ); ?>' === $(this).find('.theme-name').text() ) {
				$(".theme-info .notice-large .notice-title").text( '<?php echo esc_js( __( 'Translation Available', 'wptrads' ) ); ?>' );
				$(".theme-info .notice-large p strong").html( '<?php echo $html; ?>' );
			}
		<?php
		}
		if ( ! isset( $_GET['theme'] ) || $theme_slug !== $_GET['theme'] ) {
		?>
		});
		<?php
		}
	}
	?>
	});
	</script>
<?php
}

add_action( 'admin_menu', 'wptutsplus_change_post_menu_label' );
/**
 * Add a notification bubble on menu for themes too
 *
 * @since 1.0
 * @author Julio Potier
 *
 **/
function wptutsplus_change_post_menu_label() {
    global $menu, $submenu;
    $update_data = wp_get_update_data();
    if ( isset( $update_data['counts']['themes'] ) && $update_data['counts']['themes'] > 0 ) {
    	$count = sprintf( ' <span class="update-plugins count-%1$d"><span class="update-count">%1$d</span></span>', $update_data['counts']['themes'] );
		$menu[60][0]                 .= $count;
		$submenu['themes.php'][5][0] .= $count;
	}
}

add_filter( 'wp_get_update_data', 'wptrads_get_update_data' );
/**
 * Fix the numbers of update everywhere, I hope
 *
 * @since 1.0
 * @author Julio Potier
 *
 **/
function wptrads_get_update_data( $update_data ) {
	$titles         = array();
	if ( $update_data['counts']['translations'] ) {
		$titles['translations'] = __( 'Translation Updates' );
	}

	// Plugins
	$products       = wptrads_get_products( 'plugins' );
	$update_trans   = 0;
	$plugins        = get_plugins();
	foreach ( $products as $folder => $product ) {
		if ( isset( $product['new_version'] ) && version_compare( $product['new_version'], isset( $product['last_update'] ) ? $product['last_update'] : 0, '>' ) && ! isset( $wp_plugins_updates->response[ $folder ] ) ) {
			foreach ( $plugins as $path => $data ) {
				if ( wptrads_get_plugin_folder( $path ) === $folder ) {
					$update_trans++;
				}
			}
		}
	}
	remove_filter( 'site_transient_update_plugins', 'wptrads_site_transient_update_plugins', 1000 );
	$wp_plugins_updates               = get_site_transient( 'update_plugins' );
	$wp_plugins_count                 = isset( $wp_plugins_updates->response ) ? count( $wp_plugins_updates->response ) : 0;
	add_filter( 'site_transient_update_plugins', 'wptrads_site_transient_update_plugins', 1000 );
	$update_data['counts']['plugins'] = $update_trans + $wp_plugins_count;

	// Themes
	$products          = wptrads_get_products( 'themes' );
	$update_trans      = 0;
	$themes            = wp_get_themes();
	remove_filter( 'site_transient_update_themes', 'wptrads_site_transient_update_themes', 1000 );
	$wp_themes_updates = get_site_transient( 'update_themes' );
	$wp_themes_count   = isset( $wp_themes_updates->response ) ? count( $wp_themes_updates->response ) : 0;
	add_filter( 'site_transient_update_themes', 'wptrads_site_transient_update_themes', 1000 );
	foreach ( $products as $folder => $product ) {
		if ( isset( $product['new_version'] ) && version_compare( $product['new_version'], isset( $product['last_update'] ) ? $product['last_update'] : 0, '>' ) && ! isset( $wp_themes_updates->response[ $folder ] ) ) {
			foreach ( $themes as $path => $data ) {
				if ( $path === $folder ) {
					$update_trans++;
				}
			}
		}
	}
	$update_data['counts']['themes'] = $update_trans + $wp_themes_count;

	$update_data['counts']['total']  = $wp_themes_count + $wp_plugins_count;

	// I18n
	if ( $update_data['counts']['wordpress'] ) {
		/* translators: %d: Number of available WordPress updates. */
		$titles['wordpress'] = sprintf( __( '%d WordPress Update' ), $update_data['counts']['wordpress'] );
	}
	if ( $update_data['counts']['plugins'] ) {
		/* translators: %d: Number of available plugin updates. */
		$titles['plugins'] = sprintf( _n( '%d Plugin Update', '%d Plugin Updates', $update_data['counts']['plugins'] ), $update_data['counts']['plugins'] );
	}
	if ( $update_data['counts']['themes'] ) {
		/* translators: %d: Number of available theme updates. */
		$titles['themes'] = sprintf( _n( '%d Theme Update', '%d Theme Updates', $update_data['counts']['themes'] ), $update_data['counts']['themes'] );
	}

	$update_title         = $titles ? esc_attr( implode( ', ', $titles ) ) : '';
	$update_data['title'] = $update_title;
	return $update_data;
}

